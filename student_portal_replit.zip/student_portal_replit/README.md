# Student Portal (Replit-ready)

A simple role-based student management website built with Python Flask and SQLite.

## Run it on Replit
1. Create a new **Python** Repl.
2. Upload the files in this folder (keep `templates/` and `static/` folders).
3. Open the Shell and run `pip install -r requirements.txt`.
4. Click **Run** (or run `python app.py`).
5. Open the web preview.

## First login
- Username: `teacher`
- Password: `teacher123`

Log in and open **My profile** to change the teacher name, username, contact details, and password. Change the starter password before adding real student records.

## Features
- Teacher and student login with hashed passwords
- Teacher can edit her own profile and change her password
- Teacher can create, search, edit, and delete student accounts
- Teacher can mark or update attendance by date (Present, Absent, Late)
- Teacher can enter and delete grades, with marks validation
- Reports for attendance percentage and average grade percentage
- Students can see only their own profile, attendance, and grades
- SQLite database is created automatically as `school.db`

## Notes
- Use fictional records while testing. Before using real student data, deploy only over HTTPS, set a strong `SECRET_KEY` environment variable in Replit Secrets, and use a private Repl with access limited to authorized people.
- This is a small starter project, not a fully audited production school information system.
