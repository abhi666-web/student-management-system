import os
import sqlite3
from functools import wraps
from datetime import date
from flask import Flask, render_template, request, redirect, url_for, session, flash, g, abort
from werkzeug.security import generate_password_hash, check_password_hash

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, 'school.db')
app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'change-this-secret-key-before-public-deployment')


def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute('PRAGMA foreign_keys = ON')
    return g.db


@app.teardown_appcontext
def close_db(_error=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()


def init_db():
    db = sqlite3.connect(DB_PATH)
    db.execute('PRAGMA foreign_keys = ON')
    db.executescript('''
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('teacher','student')),
      full_name TEXT NOT NULL,
      email TEXT DEFAULT '',
      phone TEXT DEFAULT '',
      student_id TEXT UNIQUE,
      class_name TEXT DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS attendance (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      attendance_date TEXT NOT NULL,
      status TEXT NOT NULL CHECK(status IN ('Present','Absent','Late')),
      UNIQUE(student_user_id, attendance_date)
    );
    CREATE TABLE IF NOT EXISTS grades (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      subject TEXT NOT NULL,
      marks REAL NOT NULL CHECK(marks >= 0 AND marks <= 100),
      max_marks REAL NOT NULL DEFAULT 100 CHECK(max_marks > 0),
      notes TEXT DEFAULT ''
    );
    ''')
    teacher = db.execute("SELECT id FROM users WHERE role='teacher' LIMIT 1").fetchone()
    if not teacher:
        db.execute('INSERT INTO users (username,password_hash,role,full_name,email,phone) VALUES (?,?,?,?,?,?)',
                   ('teacher', generate_password_hash('teacher123'), 'teacher', 'Teacher', '', ''))
    db.commit()
    db.close()


def login_required(role=None):
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if not session.get('user_id'):
                return redirect(url_for('login'))
            if role and session.get('role') != role:
                abort(403)
            return view(*args, **kwargs)
        return wrapped
    return decorator


def current_user():
    if not session.get('user_id'):
        return None
    return get_db().execute('SELECT * FROM users WHERE id=?', (session['user_id'],)).fetchone()


@app.context_processor
def inject_user():
    return {'current_user': current_user(), 'today': date.today().isoformat()}


@app.route('/')
def index():
    if session.get('user_id'):
        return redirect(url_for('teacher_dashboard' if session.get('role') == 'teacher' else 'student_dashboard'))
    return redirect(url_for('login'))


@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username','').strip()
        password = request.form.get('password','')
        user = get_db().execute('SELECT * FROM users WHERE username=?', (username,)).fetchone()
        if user and check_password_hash(user['password_hash'], password):
            session.clear()
            session['user_id'] = user['id']
            session['role'] = user['role']
            flash('Welcome back!', 'success')
            return redirect(url_for('teacher_dashboard' if user['role']=='teacher' else 'student_dashboard'))
        flash('Incorrect username or password.', 'error')
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'success')
    return redirect(url_for('login'))


@app.route('/teacher')
@login_required('teacher')
def teacher_dashboard():
    db = get_db()
    students = db.execute("SELECT * FROM users WHERE role='student' ORDER BY full_name").fetchall()
    attendance_total = db.execute('SELECT COUNT(*) FROM attendance').fetchone()[0]
    present_total = db.execute("SELECT COUNT(*) FROM attendance WHERE status='Present'").fetchone()[0]
    recent = db.execute('''SELECT a.attendance_date,a.status,u.full_name,u.student_id FROM attendance a
                           JOIN users u ON u.id=a.student_user_id ORDER BY a.attendance_date DESC,a.id DESC LIMIT 8''').fetchall()
    return render_template('teacher_dashboard.html', students=students, attendance_total=attendance_total,
                           present_total=present_total, recent=recent)


@app.route('/students')
@login_required('teacher')
def students():
    q = request.args.get('q','').strip()
    db = get_db()
    rows = db.execute("SELECT * FROM users WHERE role='student' AND (full_name LIKE ? OR student_id LIKE ? OR username LIKE ?) ORDER BY full_name",
                      (f'%{q}%', f'%{q}%', f'%{q}%')).fetchall()
    return render_template('students.html', students=rows, q=q)


@app.route('/students/add', methods=['GET','POST'])
@login_required('teacher')
def add_student():
    if request.method == 'POST':
        full_name = request.form.get('full_name','').strip()
        student_id = request.form.get('student_id','').strip()
        username = request.form.get('username','').strip()
        password = request.form.get('password','')
        email = request.form.get('email','').strip()
        phone = request.form.get('phone','').strip()
        class_name = request.form.get('class_name','').strip()
        if not all([full_name, student_id, username, password]):
            flash('Name, student ID, username, and password are required.', 'error')
        else:
            try:
                get_db().execute('''INSERT INTO users(username,password_hash,role,full_name,email,phone,student_id,class_name)
                                    VALUES(?,?, 'student',?,?,?,?,?)''',
                                 (username, generate_password_hash(password), full_name, email, phone, student_id, class_name))
                get_db().commit()
                flash('Student account created.', 'success')
                return redirect(url_for('students'))
            except sqlite3.IntegrityError:
                flash('That username or student ID is already in use.', 'error')
    return render_template('student_form.html', student=None)


@app.route('/students/<int:user_id>/edit', methods=['GET','POST'])
@login_required('teacher')
def edit_student(user_id):
    db = get_db()
    student = db.execute("SELECT * FROM users WHERE id=? AND role='student'", (user_id,)).fetchone()
    if not student:
        abort(404)
    if request.method == 'POST':
        fields = [request.form.get(k,'').strip() for k in ('full_name','student_id','username','email','phone','class_name')]
        full_name, student_id, username, email, phone, class_name = fields
        new_password = request.form.get('password','')
        if not all([full_name, student_id, username]):
            flash('Name, student ID, and username are required.', 'error')
        else:
            try:
                if new_password:
                    db.execute('''UPDATE users SET full_name=?,student_id=?,username=?,email=?,phone=?,class_name=?,password_hash=? WHERE id=?''',
                               (full_name,student_id,username,email,phone,class_name,generate_password_hash(new_password),user_id))
                else:
                    db.execute('''UPDATE users SET full_name=?,student_id=?,username=?,email=?,phone=?,class_name=? WHERE id=?''',
                               (full_name,student_id,username,email,phone,class_name,user_id))
                db.commit()
                flash('Student details updated.', 'success')
                return redirect(url_for('students'))
            except sqlite3.IntegrityError:
                flash('That username or student ID is already in use.', 'error')
        student = db.execute('SELECT * FROM users WHERE id=?', (user_id,)).fetchone()
    return render_template('student_form.html', student=student)


@app.route('/students/<int:user_id>/delete', methods=['POST'])
@login_required('teacher')
def delete_student(user_id):
    db = get_db()
    db.execute("DELETE FROM users WHERE id=? AND role='student'", (user_id,))
    db.commit()
    flash('Student account deleted.', 'success')
    return redirect(url_for('students'))


@app.route('/attendance', methods=['GET','POST'])
@login_required('teacher')
def attendance():
    db = get_db()
    student_list = db.execute("SELECT id,full_name,student_id FROM users WHERE role='student' ORDER BY full_name").fetchall()
    chosen_date = request.values.get('attendance_date', date.today().isoformat())
    if request.method == 'POST':
        for student in student_list:
            status = request.form.get(f"status_{student['id']}")
            if status in ('Present','Absent','Late'):
                db.execute('''INSERT INTO attendance(student_user_id,attendance_date,status) VALUES(?,?,?)
                              ON CONFLICT(student_user_id,attendance_date) DO UPDATE SET status=excluded.status''',
                           (student['id'], chosen_date, status))
        db.commit()
        flash('Attendance saved.', 'success')
        return redirect(url_for('attendance', attendance_date=chosen_date))
    records = db.execute('SELECT student_user_id,status FROM attendance WHERE attendance_date=?', (chosen_date,)).fetchall()
    status_by_id = {r['student_user_id']: r['status'] for r in records}
    history = db.execute('''SELECT a.attendance_date,a.status,u.full_name,u.student_id FROM attendance a
                            JOIN users u ON u.id=a.student_user_id ORDER BY a.attendance_date DESC,a.id DESC LIMIT 30''').fetchall()
    return render_template('attendance.html', students=student_list, chosen_date=chosen_date, status_by_id=status_by_id, history=history)


@app.route('/grades', methods=['GET','POST'])
@login_required('teacher')
def grades():
    db = get_db()
    student_list = db.execute("SELECT id,full_name,student_id FROM users WHERE role='student' ORDER BY full_name").fetchall()
    if request.method == 'POST':
        try:
            student_user_id = int(request.form.get('student_user_id',''))
            subject = request.form.get('subject','').strip()
            marks = float(request.form.get('marks',''))
            max_marks = float(request.form.get('max_marks','100'))
            notes = request.form.get('notes','').strip()
            valid_student = db.execute("SELECT id FROM users WHERE id=? AND role='student'", (student_user_id,)).fetchone()
            if not valid_student or not subject or max_marks <= 0 or marks < 0 or marks > max_marks:
                raise ValueError
            db.execute('INSERT INTO grades(student_user_id,subject,marks,max_marks,notes) VALUES(?,?,?,?,?)',
                       (student_user_id,subject,marks,max_marks,notes))
            db.commit()
            flash('Grade saved.', 'success')
            return redirect(url_for('grades'))
        except (ValueError, TypeError):
            flash('Check the student, subject, and marks. Marks must be between 0 and maximum marks.', 'error')
    rows = db.execute('''SELECT g.*,u.full_name,u.student_id FROM grades g JOIN users u ON u.id=g.student_user_id
                         ORDER BY g.id DESC''').fetchall()
    return render_template('grades.html', students=student_list, grades=rows)


@app.route('/grades/<int:grade_id>/delete', methods=['POST'])
@login_required('teacher')
def delete_grade(grade_id):
    get_db().execute('DELETE FROM grades WHERE id=?', (grade_id,))
    get_db().commit()
    flash('Grade deleted.', 'success')
    return redirect(url_for('grades'))


@app.route('/reports')
@login_required('teacher')
def reports():
    rows = get_db().execute('''SELECT u.id,u.full_name,u.student_id,u.class_name,
       COUNT(a.id) AS total_days,
       SUM(CASE WHEN a.status='Present' THEN 1 ELSE 0 END) AS present_days,
       ROUND(100.0*SUM(CASE WHEN a.status='Present' THEN 1 ELSE 0 END)/NULLIF(COUNT(a.id),0),1) AS attendance_pct,
       COUNT(DISTINCT g.id) AS grade_count,
       ROUND(AVG(100.0*g.marks/g.max_marks),1) AS average_pct
       FROM users u LEFT JOIN attendance a ON a.student_user_id=u.id
       LEFT JOIN grades g ON g.student_user_id=u.id
       WHERE u.role='student' GROUP BY u.id ORDER BY u.full_name''').fetchall()
    # Avoid inflated attendance counts from joining attendance and grades by calculating per student separately.
    fixed_rows = []
    for s in get_db().execute("SELECT * FROM users WHERE role='student' ORDER BY full_name").fetchall():
        att = get_db().execute("SELECT COUNT(*) total, SUM(CASE WHEN status='Present' THEN 1 ELSE 0 END) present FROM attendance WHERE student_user_id=?", (s['id'],)).fetchone()
        gr = get_db().execute("SELECT COUNT(*) n, AVG(100.0*marks/max_marks) avg FROM grades WHERE student_user_id=?", (s['id'],)).fetchone()
        fixed_rows.append({'full_name':s['full_name'],'student_id':s['student_id'],'class_name':s['class_name'],
                           'total_days':att['total'],'present_days':att['present'] or 0,
                           'attendance_pct':round(100*(att['present'] or 0)/att['total'],1) if att['total'] else None,
                           'grade_count':gr['n'],'average_pct':round(gr['avg'],1) if gr['avg'] is not None else None})
    return render_template('reports.html', rows=fixed_rows)


@app.route('/profile', methods=['GET','POST'])
@login_required()
def profile():
    db = get_db()
    user = current_user()
    if request.method == 'POST':
        full_name = request.form.get('full_name','').strip()
        username = request.form.get('username','').strip()
        email = request.form.get('email','').strip()
        phone = request.form.get('phone','').strip()
        old_password = request.form.get('old_password','')
        new_password = request.form.get('new_password','')
        if not full_name or not username:
            flash('Name and username are required.', 'error')
        elif new_password and (not old_password or not check_password_hash(user['password_hash'], old_password)):
            flash('Enter your current password correctly to set a new password.', 'error')
        else:
            try:
                if new_password:
                    db.execute('UPDATE users SET full_name=?,username=?,email=?,phone=?,password_hash=? WHERE id=?',
                               (full_name,username,email,phone,generate_password_hash(new_password),user['id']))
                else:
                    db.execute('UPDATE users SET full_name=?,username=?,email=?,phone=? WHERE id=?',
                               (full_name,username,email,phone,user['id']))
                db.commit()
                flash('Your profile has been updated.', 'success')
                return redirect(url_for('profile'))
            except sqlite3.IntegrityError:
                flash('That username is already taken.', 'error')
        user = current_user()
    return render_template('profile.html', user=user)


@app.route('/my-records')
@login_required('student')
def student_dashboard():
    db = get_db()
    user_id = session['user_id']
    records = db.execute('SELECT attendance_date,status FROM attendance WHERE student_user_id=? ORDER BY attendance_date DESC', (user_id,)).fetchall()
    grades = db.execute('SELECT subject,marks,max_marks,notes FROM grades WHERE student_user_id=? ORDER BY id DESC', (user_id,)).fetchall()
    present = sum(1 for r in records if r['status']=='Present')
    attendance_pct = round(100*present/len(records),1) if records else None
    return render_template('student_dashboard.html', attendance=records, grades=grades, attendance_pct=attendance_pct)


@app.errorhandler(403)
def forbidden(_error):
    return render_template('error.html', code=403, message='You do not have permission to view this page.'), 403


@app.errorhandler(404)
def not_found(_error):
    return render_template('error.html', code=404, message='The page or record was not found.'), 404


init_db()
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5000)), debug=False)
